package amstechconstruction;

public class Flat {
    
    private int area ;
    private int price;
    
    public Flat(int area, int price){
        
        this.area = area;
        this.price = price;
    }
    
    public int getOfficePrice(){
        
        return (area*price);
    }
    
    public double getRegistryCharges(){
        
        return ((area)/100)*10;
    }
    
    public double getNagarNigamTax(){
        
        return ((area)/100)*1;
    }
    
    public double getFinalPrice(){
        
        return (area)*(price)+getRegistryCharges()+getNagarNigamTax()+100000;
    }
    public void displayFlat(){
       
        System.out.println("flat area : "+area);
        System.out.println("flat price acc. to area : "+getOfficePrice());
        System.out.println("flat registry charge  : "+getRegistryCharges());
        System.out.println("flat nagar nigam tax : "+getNagarNigamTax());
        System.out.println("society development tax : "+100000);
        System.out.println("final price of the flat : "+getFinalPrice()+"\n");
    }
    
}
