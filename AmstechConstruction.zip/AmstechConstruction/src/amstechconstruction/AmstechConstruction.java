package amstechconstruction;

public class AmstechConstruction {

    public static void main(String[] args) {
        
        Plot p = new Plot(50, 20, 3500);
        p.displayPlot();
        
        Office o= new Office(35, 15, 3200);
        o.displayOffice();
        
        Flat f= new Flat(3000, 2999);
        f.displayFlat();
    }
    
}
