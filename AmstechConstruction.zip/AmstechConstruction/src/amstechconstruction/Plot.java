package amstechconstruction;

public class Plot {
    
    private int length;
    private int breadth;
    private int price;
    
    public Plot(int length ,int breadth, int price){
        
        this.length = length;
        this.breadth = breadth;
        this.price = price;
    }
    
    public double getPlotPice(){
        
       return (length*breadth)*(price);
    }
    public double getRegistryCharges(){
        
        return ((length*breadth)/100)*10;
    }
    
    public double getNagarNigamTax(){
        
        return ((length*breadth)/100)*1;
    }
    
    public double getFinalPrice(){
        
        return (length*breadth)*(price)+getRegistryCharges()+getNagarNigamTax()+100000;
    }
    public void displayPlot(){
        
        System.out.println("plot length : "+length);
        System.out.println("plot breadth : "+breadth);
        System.out.println("plot area : "+(length*breadth));
        System.out.println("plot price acc. to area : "+getPlotPice());
        System.out.println("plot registry charge  : "+getRegistryCharges());
        System.out.println("plot nagar nigam tax : "+getNagarNigamTax());
        System.out.println("society development tax : "+100000);
        System.out.println("final price of the plot : "+getFinalPrice()+"\n");
    }
}
