package amstechconstruction;

public class Office {
    
    private int length;
    private int breadth;
    private int price;
    
    public Office(int length ,int breadth, int price){
        
        this.length = length;
        this.breadth = breadth;
        this.price = price;
    }
    
    public int getOfficeArea(){
        
        return (length*breadth);
    }
    
    public int getOfficePrice(){
        
        return (length*breadth)*(price);
    }
    
    public double getRegistryCharges(){
        
        return ((length*breadth)/100)*10;
    }
    
    public double getNagarNigamTax(){
        
        return ((length*breadth)/100)*1;
    }
    
    public double getFinalPrice(){
        
        return (length*breadth)*(price)+getRegistryCharges()+getNagarNigamTax()+100000;
    }
    public void displayOffice(){
        
        System.out.println("office lrngth : "+length);
        System.out.println("office breadth : "+breadth);
        System.out.println("office area : "+(length*breadth));
        System.out.println("office price acc. to area : "+getOfficePrice());
        System.out.println("office registry charge  : "+getRegistryCharges());
        System.out.println("office nagar nigam tax : "+getNagarNigamTax());
        System.out.println("society development tax : "+100000);
        System.out.println("final price of the office : "+getFinalPrice()+"\n");
    }
}
